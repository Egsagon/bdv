/* Injection for the ADFS */

window.bdv.init(false, () => {})
